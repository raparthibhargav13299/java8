package com.stackroute.defaultmethods;

public class RectangleTests {


}