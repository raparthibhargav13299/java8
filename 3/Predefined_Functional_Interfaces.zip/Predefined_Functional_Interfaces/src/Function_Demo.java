import java.util.function.Function;

public class Function_Demo {
    public static void main(String[] args) {
        Function<String, Integer> f1=(s)->s.length();
        Function<Integer, Integer> f2=(n)->n=n*n;
        System.out.println(f1.apply("TIGER"));
        System.out.println("SQRT of 4 ="+f2.apply(4));
    }
}
