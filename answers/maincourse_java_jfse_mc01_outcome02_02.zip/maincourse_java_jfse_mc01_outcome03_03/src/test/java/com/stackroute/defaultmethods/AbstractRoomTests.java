package com.stackroute.defaultmethods;

public class AbstractRoomTests {
    AbstractRoom abstractRoom;

}