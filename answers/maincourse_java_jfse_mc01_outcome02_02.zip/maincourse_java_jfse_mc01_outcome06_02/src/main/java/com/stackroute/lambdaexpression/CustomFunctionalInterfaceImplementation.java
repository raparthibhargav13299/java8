package com.stackroute.lambdaexpression;
public class CustomFunctionalInterfaceImplementation {
    MyFunction<Integer> cubeOfNumber = (Integer num1) ->{return num1*num1*num1;};
    MyFunction<String> changedCase = (String str) ->
    {
        String changeCase = "";
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if (Character.isUpperCase(c)) {
                c = Character.toLowerCase(c);
                changeCase += c;

            } else if (Character.isLowerCase(c)) {
                c = Character.toUpperCase(c);
                changeCase += c;

            }

        }
        return changeCase;
    };

    public static void main(String args[]) {
        CustomFunctionalInterfaceImplementation myFunction = new CustomFunctionalInterfaceImplementation();
        System.out.println(myFunction.cubeOfNumber.doJob(2));
        System.out.println(myFunction.changedCase.doJob("yamini"));
    }
}






















