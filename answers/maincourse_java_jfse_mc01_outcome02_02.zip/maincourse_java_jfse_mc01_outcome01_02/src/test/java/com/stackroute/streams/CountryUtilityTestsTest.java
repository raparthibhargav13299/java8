package com.stackroute.streams;
import com.sun.source.doctree.SeeTree;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import javax.management.ConstructorParameters;
import java.util.*;
import java.util.stream.Collector;
import static org.junit.jupiter.api.Assertions.*;

class CountryUtilityTestsTest{
    CountryUtility countryUtility;
    List<String> listCountry;
    Map<String,String> map;
    @BeforeEach
    void setUp() {
        countryUtility=new CountryUtility();
        listCountry=new ArrayList<>();
        listCountry.add("India-Delhi");
        listCountry.add("Comoros-Moroni");
        listCountry.add("Canada-Ottawa");
        listCountry.add("Denmark-Copenhagen");
        listCountry.add("china-Beijing");
        listCountry.add("Cube-Havana");
        listCountry.add("USA-Washington");
        map=new HashMap<>();
        map.put("India","Delhi");
        map.put("Canada","Ottawa");

        map.put("USA","Washington");
        map.put("Japan","Tokyo");
        map.put("Cuba","Havana");
    }
    @Test
void getCountryByCapitalTest()
    {
        assertEquals("India",countryUtility.getCountryByCapital(map,"Delhi"));
    }
    @ParameterizedTest
@ValueSource(strings={"India-deLhi","Cuba-Havana","Australia-Canberra","China-Beijing"})
    void  searchCountryTest(String string)
    {
        assertTrue(countryUtility.searchCountry(listCountry,string));
    }
    @ParameterizedTest
    @ValueSource(strings={""," "})
    void searchCountryEmptyTest(String string)
    {
        assertFalse(countryUtility.searchCountry(listCountry,string));
    }
    @ParameterizedTest
    @ValueSource(strings={"Indian-cube","Nepal-Kathmandu","Bhutan-thimphu"})
    void searchFruitFalseTest(String string){

        assertFalse(countryUtility.searchCountry(listCountry,string));
    }
}