package Lambda_Expression;
interface Dream{
    void everyDayDream();
}
public class LambdaExpressionDemo {
    public static void main(String[] args) {
        Dream obj=()->{ System.out.println("Hello I see Every Day a Dream");};
        obj.everyDayDream();
    }
}
