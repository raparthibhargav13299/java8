import java.util.function.Consumer;

public class Consumer_Demo {
    public static void main(String[] args) {
        Consumer<Integer> con=(i)->{
           for(int k=1;k<10;k++){
               System.out.println(i*k);
           }
        };

        con.accept(10);
    }
}
