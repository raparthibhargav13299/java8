package com.stackroute.lambdaexpression;

public class CustomFunctionalInterfaceImplmentationTests {
    private  CustomFunctionalInterfaceImplementation customFunctionalInterfaceImplementation;
}
