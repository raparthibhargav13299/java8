import java.time.LocalTime;

public class MyTime {
    public static void main(String[] args) {
        LocalTime time=LocalTime.now();
        //after two hours time
        System.out.println(time.plusHours(2));
    }
}
