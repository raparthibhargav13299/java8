import java.util.function.IntFunction;
import java.util.function.IntPredicate;
import java.util.function.Predicate;

public class Problem_With_Predicate {
    public static void main(String[] args) {
        IntPredicate pre=(i)->i%2==0;
        System.out.println(pre.test(2));

        IntFunction fc=(num)->num=num*num;

        System.out.println(fc.apply(4));
    }
}
