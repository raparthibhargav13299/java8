interface Left{
    default void show(){
        System.out.println("Left Show");
    }
}
interface Right {
    default void show(){
        System.out.println("Right Show");
    }
}
public class Static_Method implements Left, Right{
    @Override
    public void show() {
        Left.super.show();
    }
    public static void main(String[] args) {
        Static_Method obj=new Static_Method();
        obj.show();
    }
}
