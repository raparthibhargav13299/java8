import java.util.function.Function;

class Employee_Per{
    String name;
    int supervisorRating;

    public Employee_Per(String name, int supervisorRating){
        this.name=name;
        this.supervisorRating=supervisorRating;
    }
}
public class Employee_Awards {
    public static void main(String[] args) {
        Function<Employee_Per, String> fc=(emp)->{
            int rating=emp.supervisorRating;
            String title="";
            if(rating>=8 && rating<=10)
                title="The Employee of the month";
            else if(rating>=5 && rating<=7)
                title="Stand out performer";
            else if(rating>=2 && rating<=4)
                title="Go that extra mile";
            else {
                title="Work Hard";
            }
            return title;
        };
        Employee_Per emp1=new Employee_Per("Parker",8);
        Employee_Per emp2=new Employee_Per("Parker",5);
        System.out.println(fc.apply(emp1));
        System.out.println(fc.apply(emp2));
    }
}
