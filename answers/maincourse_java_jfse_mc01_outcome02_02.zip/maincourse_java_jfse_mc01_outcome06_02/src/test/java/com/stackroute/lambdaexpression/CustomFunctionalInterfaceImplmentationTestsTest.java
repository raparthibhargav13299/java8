package com.stackroute.lambdaexpression;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CustomFunctionalInterfaceImplmentationTestsTest {
    private CustomFunctionalInterfaceImplementation customFunctionalInterfaceImplementation;
    private String MSG_01="Return the string value";

    @BeforeEach
    void setUp() {customFunctionalInterfaceImplementation=new CustomFunctionalInterfaceImplementation();
    }

    @AfterEach
    void tearDown() {customFunctionalInterfaceImplementation=null;
    }
    @Test
    void TwoIntergerCubeOfNumberReturnOutput()
    {
        assertEquals( 8, customFunctionalInterfaceImplementation.cubeOfNumber.doJob(2));
        assertEquals( 125,customFunctionalInterfaceImplementation.cubeOfNumber.doJob(5));
        assertEquals(64,customFunctionalInterfaceImplementation.cubeOfNumber.doJob(4));

    }
    @Test
    void givenNegativeNumberReturnCube()
    {
        assertNotEquals(19,customFunctionalInterfaceImplementation.cubeOfNumber.doJob(5));
        assertNotEquals(9,customFunctionalInterfaceImplementation.cubeOfNumber.doJob(7));
    }
    @Test
    void givenStringNullThenReturnEmptyString()
    {
        String expected="";
        assertThrows(NullPointerException.class,()->customFunctionalInterfaceImplementation.cubeOfNumber.doJob(0));

    }
    @Test
    void  givenStringMixedCase()
    {

        assertEquals("YAmini",customFunctionalInterfaceImplementation.changedCase.doJob("yaMINI"));
    }
@Test
    public void givenZeroReturnZero()
{
    assertEquals("stack",customFunctionalInterfaceImplementation.changedCase.doJob("STACK"));
}






}