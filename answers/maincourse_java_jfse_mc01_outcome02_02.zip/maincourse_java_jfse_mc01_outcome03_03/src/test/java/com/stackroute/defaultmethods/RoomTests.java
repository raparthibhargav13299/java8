package com.stackroute.defaultmethods;

public class RoomTests {
    Room room;


}