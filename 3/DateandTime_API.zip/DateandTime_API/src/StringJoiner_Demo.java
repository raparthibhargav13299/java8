import java.util.StringJoiner;

public class StringJoiner_Demo {
    public static void main(String[] args) {
        StringJoiner str=new StringJoiner(" - ");
        str.add("Helen");
        str.add("Selina");
        str.add("Rosy");
        str.add("Kim");
        str.add("Tio");

        System.out.println(str);

        StringJoiner str1=new StringJoiner(" , ",":-","-:");
        str1.add("Helen");
        str1.add("Selina");
        str1.add("Rosy");
        str1.add("Kim");
        str1.add("Tio");

        System.out.println(str1);

    }
}
