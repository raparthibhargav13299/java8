import java.util.function.Function;

public class Function_Chaining {
    public static void main(String[] args) {
        Function<Integer, Integer> f1=(i)->i=i*10;
        Function<Integer, Integer> f2=(i)->i=i+5;

        //compose()
        System.out.println("After f1="+f1.apply(5));
        System.out.println("After f1 & f2="+f1.compose(f2).apply(5));
    }
}
