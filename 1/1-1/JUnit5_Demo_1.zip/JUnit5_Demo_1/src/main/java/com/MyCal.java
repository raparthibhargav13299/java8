package com;

public class MyCal {
    public static int add(String num){
        if(num.isEmpty()){
            return 0;
        }
        int numReturn=0;
        String numberArray[]=num.split(",");
        for(String i: numberArray){
            numReturn+=Integer.parseInt(i);
        }
        return numReturn;
    }
}
