import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.Temporal;

public class MyPeriod_Demo {
    public static void main(String[] args) {
        Period p= Period.ofDays(5);

        //Adding four days period to current time
        Temporal temp=p.addTo(LocalDate.now());
        System.out.println(temp);

        Period p1=Period.of(2016,05,25);
        System.out.println(p1);
    }
}
