package Lambda_Expression;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class Employee{
    int id;
    String name;
    double salary;

    Employee(int id, String name, double salary){
        this.id=id;
        this.name=name;
        this.salary=salary;
    }
}
public class EmployeeSortinBasedOnSalary {
    public static void main(String[] args) {
        List<Employee> empList=new ArrayList<Employee>();
        empList.add(new Employee(101,"Andy",2500));
        empList.add(new Employee(102,"Parker",8659));
        empList.add(new Employee(103,"Misha",3654));
        empList.add(new Employee(104,"Brian",8997));
        empList.add(new Employee(105,"Curry",1236));

        List<Employee> finalEmpList=empList.stream().filter((emp)->emp.salary>3500).collect(Collectors.toList());

        for(Employee emp: finalEmpList){
            System.out.println(emp.id);
            System.out.println(emp.name);
            System.out.println(emp.salary);
            System.out.println("------------");
        }

    }
}
