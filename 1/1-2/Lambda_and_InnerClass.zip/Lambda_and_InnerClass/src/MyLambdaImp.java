@FunctionalInterface
interface Dream{
    public void rareDream();
}

public class MyLambdaImp {
    public static void main(String[] args) {
        Dream obj=()->{
            System.out.println("I saw a Rare Dream");
        };
        obj.rareDream();
    }
}
