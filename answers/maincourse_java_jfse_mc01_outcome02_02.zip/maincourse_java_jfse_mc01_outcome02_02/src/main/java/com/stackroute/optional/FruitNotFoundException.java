package com.stackroute.optional;

/* Complete the class as per the requirements given in PROBLEM.md */
public class FruitNotFoundException extends RuntimeException {
    public  FruitNotFoundException(String str)
    {
        super(str);
    }

}

