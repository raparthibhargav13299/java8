package Lambda_Expression;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;

public class MySortingWithLambda {
    public static void main(String[] args) {
        ArrayList<Integer> al=new ArrayList<Integer>();
        al.add(25);
        al.add(69);
        al.add(23);
        al.add(12);
        al.add(57);
        al.add(5);
        al.add(88);
        Comparator<Integer> com=(I1, I2)-> (I1>I2)?1: (I1<I2)?-1:0;
        Collections.sort(al, com);
        System.out.println(al);
    }
}
