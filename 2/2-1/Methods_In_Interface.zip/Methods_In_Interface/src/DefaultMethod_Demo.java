interface Mobile{
     void calling();
     void messaging();
     default void faceID(){
     }
     default void smartKeys(){
     }
}
public class DefaultMethod_Demo implements Mobile{
    public static void main(String[] args) {
        DefaultMethod_Demo obj=new DefaultMethod_Demo();
        obj.calling();
        obj.messaging();
        obj.faceID();
        obj.smartKeys();
    }
    @Override
    public void calling() {
        System.out.println("Calling Feature");
    }

    @Override
    public void messaging() {
        System.out.println("Messaging Feature");
    }
}
