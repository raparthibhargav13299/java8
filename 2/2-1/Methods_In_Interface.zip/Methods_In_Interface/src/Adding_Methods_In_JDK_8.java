interface SIMS{
    void calling();
    void sms();
    default void faceID(){
    }
}
class Airtels implements SIMS{

    @Override
    public void calling() {
        System.out.println("Airtel Calling");
    }
    @Override
    public void sms() {
        System.out.println("Airtel messaging");
    }
}
class Jios implements SIMS{

    @Override
    public void calling() {
        System.out.println("Jio Calling");
    }
    @Override
    public void sms() {
        System.out.println("Jio messaging");
    }
}
public class Adding_Methods_In_JDK_8 {
    public static void main(String[] args) {
        Airtels airtel=new Airtels();
        Jios jio=new Jios();

        airtel.calling();
        airtel.sms();

        /*JIO*/
        jio.calling();
        jio.sms();
    }
}
