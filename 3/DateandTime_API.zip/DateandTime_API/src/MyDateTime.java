import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class MyDateTime {
    public static void main(String[] args) {
        LocalDateTime myDateTime=LocalDateTime.now();
        System.out.println(myDateTime);
        //Format: yyyy-MM-dd-HH-mm-ss

        DateTimeFormatter formatter=DateTimeFormatter.ofPattern("DD.MM.YYYY HH:mm:ss");
        /*DD: Day of the year*/
        //After formatting
        String dateAfterFormat=myDateTime.format(formatter);
        System.out.println(dateAfterFormat);

        //getMonth(): APRIL
        //getMonthValue(): 4
        System.out.println(myDateTime.getMonth());


    }
}
