import java.time.LocalDate;

public class MyDate {
    public static void main(String[] args) {
        LocalDate date=LocalDate.now(); // current date of the system
        System.out.println(date);

        /*Leap year example*/
        LocalDate leap=LocalDate.of(2021,05,23); // custom date
        System.out.println("Is Leap Year ="+leap.isLeapYear());
        MyDate user1=new MyDate();
        System.out.println("Your product will be deliver on="+user1.getExpectedDeliveryDate(500048));
        MyDate user2=new MyDate();
        System.out.println("Your product will be deliver on="+user2.getExpectedDeliveryDate(32656));

    }
    public LocalDate getExpectedDeliveryDate(int pinCode){
        LocalDate orderDate=LocalDate.now();
        LocalDate expectedDate=null;

        if(pinCode==500048){
            expectedDate=orderDate.plusDays(2);
        }else if(pinCode==32656){
            expectedDate=orderDate.plusDays(5);
        }
        return expectedDate;
    }

}
