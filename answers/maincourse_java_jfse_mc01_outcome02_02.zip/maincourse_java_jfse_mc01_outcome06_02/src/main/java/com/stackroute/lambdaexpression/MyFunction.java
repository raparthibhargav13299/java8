package com.stackroute.lambdaexpression;

/* Complete the class as per the requirements given in PROBLEM.md */

public interface MyFunction<T> {
   T doJob(T t);




}
