import java.time.LocalDate;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;

public class BirthdayReminder {
    public static void main(String[] args) {
        LocalDate birthdayDate=LocalDate.of(1991, 04,23);
        LocalDate currentDate=LocalDate.now();


        int monthLeft= birthdayDate.getMonthValue()-currentDate.getMonthValue();
        int daysLeft=birthdayDate.getDayOfMonth()-currentDate.getDayOfMonth();
        System.out.println(monthLeft);
        System.out.println(daysLeft);

        int totalDays=(monthLeft*30)+daysLeft;
        for(int i=0;i<=(monthLeft*30)+daysLeft;i++)
        {
            if(totalDays==0){
                System.out.println("Today is Birthday");
                break;
            }else{
                System.out.println("John's Birthday is after: "+totalDays+" Days");
                totalDays--;
            }
        }
    }
}
