package Lambda_Expression;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;

class MySorting implements Comparator<Integer>{
    @Override
    public int compare(Integer i1, Integer i2) {
        if(i1>i2)
            return +1;
        else if(i1<i2)
            return -1;
        else
            return 0;
    }
}
public class NumberSorting  {
    public static void main(String[] args) {
        ArrayList<Integer> al=new ArrayList<Integer>();
        al.add(25);
        al.add(69);
        al.add(23);
        al.add(12);
        al.add(57);
        al.add(5);
        al.add(88);

        Collections.sort(al, new MySorting());
        System.out.println(al);

    }
}


