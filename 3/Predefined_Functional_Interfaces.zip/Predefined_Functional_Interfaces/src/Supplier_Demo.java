import java.util.function.Supplier;

public class Supplier_Demo {
    public static void main(String[] args) {
        Supplier<String> otp=()->{
            String oneTimePass="";
            for(int i=0;i<6;i++){
                oneTimePass=oneTimePass+(int)(Math.random()*10);
            }
          return oneTimePass;
        };

        System.out.println(otp.get());
        System.out.println(otp.get());
    }
}
