interface SIM{
    void calling();
    void sms();
}
interface VIDEO_CALL_3G{
    void videoCalling();
}

class Airtel implements SIM{

    @Override
    public void calling() {
        System.out.println("Airtel Calling");
    }
    @Override
    public void sms() {
        System.out.println("Airtel Messaging");
    }
}

/*AIRTEL_3G*/
/*class Airtel3G implements VIDEO_CALL_3G{

    @Override
    public void videoCalling() {
        System.out.println("Airtel 3G Video Calling");
    }
}*/
class Airtel3G extends Airtel implements SIM{
    public void videoCalling(){
        System.out.println("Video Calling");
    }
}
class Jio implements SIM{

    @Override
    public void calling() {
        System.out.println("Jio Calling");
    }
    @Override
    public void sms() {
        System.out.println("Jio Messaging");
    }
}


public class Adding_Methods_In_JDK7 {
    public static void main(String[] args) {
        Airtel3G airtel=new Airtel3G();
        airtel.calling();
        airtel.sms();
        airtel.videoCalling();
    }
}
