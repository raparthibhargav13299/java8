package Lambda_Expression;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class FilterNumbers {
    public static void main(String[] args) {
        List<Integer> ll=new ArrayList<Integer>();
        ll.add(25);
        ll.add(36);
        ll.add(16);
        ll.add(11);
        ll.add(7);
        ll.add(37);
        ll.add(42);
        ll.add(88);

        List<Integer> eList=ll.stream().filter((i)->i%2==0).collect(Collectors.toList());
        System.out.println(eList);
    }
}
