import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

class Employee{
    int id;
    String name;
    double salary;

    public Employee(int id, String name, double salary){
        this.id=id;
        this.name=name;
        this.salary=salary;
    }
}
public class PredicateEmployee {
    public static void main(String[] args) {
        List<Employee> al=new ArrayList<>();
        al.add(new Employee(101,"Andy", 4500));
        al.add(new Employee(102,"Selina", 3658));
        al.add(new Employee(103,"Tina", 7895));
        al.add(new Employee(104,"William", 1236));
        al.add(new Employee(105,"George", 9788));

        Predicate<Employee> emp=(employee)->employee.salary>4000;
        for(Employee e: al){
            if(emp.test(e)){
                System.out.println(e.id);
                System.out.println(e.name);
                System.out.println(e.salary);
                System.out.println("-----------");
            }
        }
    }
}
