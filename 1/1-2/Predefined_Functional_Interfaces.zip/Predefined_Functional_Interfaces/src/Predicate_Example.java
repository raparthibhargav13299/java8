import java.util.function.Predicate;

public class Predicate_Example {
    public static void main(String[] args) {
        Predicate<Integer> pre1=(i1)->i1<100;
        Predicate<Integer> preNegate=pre1.negate();

        /*negate()*/
        System.out.println(preNegate.test(30));
    }

}
