package com.stackroute.streams;

/* Write test cases for positive and negative scenarios*/

import java.util.List;
import java.util.Map;

public class CountryUtilityTests {
    CountryUtility countryUtility;
    List<String> listCountry;
    Map<String,String> map;
}