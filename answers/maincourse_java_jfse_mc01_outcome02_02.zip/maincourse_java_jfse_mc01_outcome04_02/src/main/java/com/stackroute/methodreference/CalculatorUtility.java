package com.stackroute.methodreference;

/* Complete the class as per the requirements given in PROBLEM.md */
public class CalculatorUtility {
    double compute(int num1,int num2)
    {
        return num1*num2;
    }




}
